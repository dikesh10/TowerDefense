package view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import model.Launcher;

import javax.swing.ImageIcon;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;


public class Start  implements ActionListener {
    private JFrame frame;
    private JButton closeButton;
    private JButton Marathon;
    private JButton levels;
    private JButton Terminal;
    private int posiX, posiY;

    public Start() {

        frame = new JFrame();

        this.posiX = 80;
        this.posiY = 600;

        JPanel panel = new JPanel(new BorderLayout());

        ImageIcon image = new ImageIcon("src/img/background/backgroundLevel.jpeg");
        JLabel label = new JLabel(image); // ajoute directement l'image

        panel.add(label, BorderLayout.CENTER);

        frame.add(panel, BorderLayout.CENTER);

        frame.setTitle("Tower-Defense");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 800);
        frame.setBackground(Color.black);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);

        JButton roundedButton_terminal = new JButton("TERMINAL") {
            {
                setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
                setBackground(new Color(0, 200, 0));
                setOpaque(true);
                setFocusPainted(false);
                setBorderPainted(false);

                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(220, 220, 220));
                    }

                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(0, 200, 0));
                    }
                });
            }
        };
        Terminal = roundedButton_terminal;
        Terminal.setBounds(posiX, posiY, 150, 30);
        Terminal.setVisible(true);
        Terminal.addActionListener(this);
        frame.add(Terminal);

        posiX += 200;

        JButton roundedButton = new JButton("CHOSE LEVELS") {
            {
                setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
                setBackground(new Color(0, 200, 0));
                setOpaque(true);
                setFocusPainted(false);
                setBorderPainted(false);

                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(220, 220, 220));
                    }

                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(0, 200, 0));
                    }
                });
            }
        };
        levels = roundedButton;
        levels.setBounds(posiX, posiY, 150, 30);
        levels.addActionListener(this);
        frame.add(levels);

        posiX += 200;

        JButton roundedButton_marathon = new JButton("MARATHON") {
            {
                setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
                setBackground(new Color(0, 200, 0));
                setOpaque(true);
                setFocusPainted(false);
                setBorderPainted(false);

                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(220, 220, 220));
                    }

                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(0, 200, 0));
                    }
                });
            }
        };
        Marathon = roundedButton_marathon;
        Marathon.setBounds(posiX, posiY, 150, 30);
        Marathon.addActionListener(this);
        frame.add(Marathon);

        posiX += 200;

        JButton roundedButton_close = new JButton("CLOSE") {
            {
                setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
                setBackground(new Color(0, 200, 0));
                setOpaque(true);
                setFocusPainted(false);
                setBorderPainted(false);

                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(220, 220, 220));
                    }

                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(0, 200, 0));
                    }
                });
            }
        };
        closeButton = roundedButton_close;
        closeButton.setBounds(posiX, posiY, 150, 30);
        closeButton.addActionListener(this);
        frame.add(closeButton);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == closeButton) {
            frame.dispose();
        }
        if (e.getSource() == levels) {
            frame.dispose();
            Levels level = new Levels();
        } else if (e.getSource() == closeButton) {
            frame.dispose();
        } else if (e.getSource() == Terminal) {
            frame.dispose();
            Launcher a = new Launcher();
        }

    }

    public static void main(String[] args) {
        new Start();

    }
}
