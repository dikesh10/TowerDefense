package view;


import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.SwingUtilities;


public class Levels extends JFrame implements ActionListener {

    private JButton facile;
    private JButton Moyen;
    private JButton Difficile;
    private int posiX, posiY;
    private Image background;

    public Levels() {

        this.posiX = 80;
        this.posiY = 600;

        this.initializeBackground();

        // Create buttons and set bounds
        JButton roundedButton_easy = new JButton("FACILE") {
            {
                setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
                setBackground(new Color(0, 200, 0));
                setOpaque(true);
                setFocusPainted(false);
                setBorderPainted(false);

                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(220, 220, 220));
                    }

                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(0, 200, 0));
                    }
                });
            }
        };
        facile = roundedButton_easy;
        facile.setBounds(posiX, posiY, 200, 50);
        facile.addActionListener(this); // Add Levels as ActionListener

        posiX += 250;

        JButton roundedButton_average = new JButton("MOYEN") {
            {
                setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
                setBackground(new Color(0, 200, 0));
                setOpaque(true);
                setFocusPainted(false);
                setBorderPainted(false);

                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(220, 220, 220));
                    }

                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(0, 200, 0));
                    }
                });
            }
        };
        Moyen = roundedButton_average;
        Moyen.setBounds(posiX, posiY, 200, 50);
        Moyen.addActionListener(this); // Add Levels as ActionListener

        posiX += 250;

        JButton roundedButton_hard = new JButton("DIFFICILE") {
            {
                setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
                setBackground(new Color(0, 200, 0));
                setOpaque(true);
                setFocusPainted(false);
                setBorderPainted(false);

                addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(220, 220, 220));
                    }

                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        setBackground(new Color(0, 200, 0));
                    }
                });
            }
        };
        Difficile = roundedButton_hard;
        Difficile.setBounds(posiX, posiY, 200, 50);
        Difficile.addActionListener(this);

        add(facile);
        add(Moyen);
        add(Difficile);

        this.setLayout(null);
        this.setSize(900, 800);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        g.drawImage(background, 0, 0, 900, 800, null);
    }

    public void initializeBackground() {
        try {
            File f = new File("src/img/imageTest.jpg");
            this.background = ImageIO.read(f);
        } catch (Exception e) {
            System.out.println("Problem loading image");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle button actions here
        if (e.getSource() == facile) {
            PlantvsZombie pvz = new PlantvsZombie();
            this.dispose();
            System.out.println("Easy button clicked!");
        } else if (e.getSource() == Moyen) {
            this.dispose();
            System.out.println("Medium button clicked!");
        } else if (e.getSource() == Difficile) {
            this.dispose();
            System.out.println("Hard button clicked!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Levels());
    }
}
