
package view;

import model.Case;
import model.MapConfig_Simple;
import model.Mob;
import model.defender.Defender1;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.Timer;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import javax.imageio.ImageIO;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import javax.swing.SwingUtilities;



public class PlantvsZombie extends JPanel implements MouseListener, MouseMotionListener {
    private MapConfig_Simple battle;

    private Case[][] map;

    private Image background;

    private Image backgroundShop;

    private Image[] gifFrames;

    private JLabel shopping;

    // private Image[] dieZombImages;
    private int currentFrameIndex = 0;

    // private int currentFrameIndex2 = 0;
    private int gifX = 0;

    private int gifXTMP = 0;

    private int posiX = 0;
    private int posiY = 0;

    private ArrayList<Mob> enemies = new ArrayList<>();

    private static int index = 0;
    private int[][] position;

    static int count = 0;

    private JLabel money = new JLabel();

    private static final String imagePath = "src/img/card/sunflower0.png";

    static boolean imageClicked = false;

    // private static final String IMAGE_PATH =
    // "src/ressources/frankenstein-150565_1280(2).png";

    private ImageIcon imageIcon;

    private List<Point> imagePositions = new ArrayList<>();

    private static boolean is_image_clicked = false;

    private List<Point> Place_disponibl = new ArrayList<>();

    private Image defenderPic;

    private card peashooter = new card(0, "peashooter");
    private card sun = new card(1, "sunflower");

    private int cellWidth, cellHeight;

    private final String[] image_links = new String[10]; // je sais

    // je dois stocker pour le moment

    private boolean is_image_clicked_sun = false;

    private boolean is_image_clicked_peashooter = false;

    public PlantvsZombie() {

        this.battle = new MapConfig_Simple();
        this.map = battle.getMap();

        this.setPreferredSize(new Dimension(900, 800));
        this.cellHeight = this.getHeight() / this.map.length;
        this.cellWidth = this.getWidth() / this.map[0].length;

        this.position = new int[battle.getCompteurEnemy()][2];

        this.initializeBackground();
        this.initializeGifMovement();
        this.initializeShopBackground();
        // this.initialiseDieShow();

        this.money.setBounds(300, 70, 500, 500);
        this.money.setBackground(new Color(0, 100, 100, 0));

        this.add(money);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);

        JFrame frame = new JFrame("Game Window");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(this);

        frame.pack();
        frame.setLocationRelativeTo(null); // Centre la fenêtre
        frame.setResizable(false);
        frame.setVisible(true);
    }

    //////////////////////////// ::DISPLAY GUI //////////////////////////

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        String money = this.battle.getPlayer().getMoney() + "";

        // Draw background
        g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
        g.drawImage(backgroundShop, 15, 3, null);

        g.drawString(money, 35, 80);

        this.cellHeight = (this.getHeight() - 100) / this.map.length;
        this.cellWidth = this.getWidth() / this.map[0].length;

        for (Point position : imagePositions) {
            g.drawImage(new ImageIcon("src/img/peashooter/Frame0.png").getImage(), position.x, position.y, this);
        }

        if (is_image_clicked_peashooter) {
            try {
                g.drawImage(imageIcon.getImage(), getMousePosition().x - (imageIcon.getIconWidth() / 2),
                        getMousePosition().y - (imageIcon.getIconHeight() / 2), this);
            } catch (Exception e) {
                System.out.println("Vous êtes en dehors de la fenêtre");
            }

        }

        drawCase(g, cellHeight, cellWidth);
        for (int line = 1; line < 6; line++) {
            g.drawImage(new ImageIcon("src/ressources/chests-01.png").getImage(), -10,
                    line * this.cellHeight, 80, 80, null);
        }

        drawEnemy(g, cellHeight, cellWidth);

        sun.showinshop_canbuy(g);
        peashooter.showinshop_canbuy(g);

    }

    /////// POUR METRTRES LES GRID///
    public void drawCase(Graphics g, int cellHeight, int cellWidth) {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                g.setColor(Color.BLACK);
                g.drawRect(j * cellWidth, (i * cellHeight) + 100, cellWidth, cellHeight);
            }
        }
    }

    public void drawEnemy(Graphics g, int cellHeight, int cellWidth) {
        boolean attack = true;
        int compteur1 = 0;
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                if (map[i][j].Get_Enemy_present()) {

                    // il faut que soit une variable global qui ne recalcul pas a chaque tour
                    // posiX = ((this.indexj * cellWidth) - cellWidth) + gifX;
                    // System.out.println("VIENT DE DRAWENEMY " + map[i][j].getMob());
                    posiX = ((map[i][j].getMob().getColonnePosi() * cellWidth) - cellWidth) + gifX; // cette fonction
                                                                                                    // fait bouger de
                                                                                                    // colonne notre
                                                                                                    // zombie et on fait
                                                                                                    // -cellewidth ou
                                                                                                    // j-1 car il y a la
                                                                                                    // marge d'erreur
                                                                                                    // avec le 0 !!

                    gifXTMP = ((j * cellWidth) / cellWidth);

                    posiY = (i * cellHeight) + 100;

                    g.drawImage(gifFrames[currentFrameIndex], posiX, posiY, 100, 100, null);

                    position[compteur1][0] = posiY / cellHeight;
                    position[compteur1][1] = (posiX + cellWidth + cellWidth / 4) / cellWidth;

                    if (position[compteur1][1] != j) {

                        map[i][j].setPresent(false);
                        map[i][j - 1].setPresent(true);
                        map[i][j].Set_Enemy_present(false);
                        map[i][j - 1].Set_Enemy_present(true);
                        Mob tmp = map[i][j].getMob();
                        map[i][j].setMob(null);
                        map[i][j - 1].setMob(tmp);

                        gifXTMP = ((j * cellWidth)) / cellWidth;
                        if (attack) {

                            battle.afficher();
                            battle.attack();
                            attack = false;
                        }
                    }

                    if (posiX + cellWidth == 0) {
                        end();
                    }
                    compteur1 += 1;
                }
            }
        }
    }

    // public void showDeath(Graphics g, int posiX, int posiY) {
    // g.drawImage(dieZombImages[currentFrameIndex2], posiX, posiY, 50, 50, null);
    // }

    private void initializeBackground() {
        try {
            background = ImageIO.read(new File("src/img/background/backgroundv2.jpeg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void initializeShopBackground() {
        try {
            backgroundShop = ImageIO.read(new File("src/img/background/shopping.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // pour le moment c'est nul
    // public void initialiseDieShow() {
    // try {

    // dieZombImages = new Image[12];
    // for (int pages = 0; pages < 12; pages++) {
    // dieZombImages[pages] = ImageIO.read(new File("src/ressources/zombiedie/Frame"
    // + pages + ".png"));
    // }

    // // Créer le mouvement des ennemis
    // Timer timer = new Timer(100, new ActionListener() {
    // @Override
    // public void actionPerformed(ActionEvent e) {
    // currentFrameIndex2 = (currentFrameIndex2 + 1) % dieZombImages.length;
    // repaint();
    // }
    // });
    // timer.start();

    // } catch (IOException e) {
    // e.printStackTrace();
    // }
    // }

    private void initializeGifMovement() {
        try {
            gifFrames = new Image[18];
            for (int i = 0; i < 18; i++) {
                gifFrames[i] = ImageIO.read(new File("src/img/darkzombie/Frame" + i + ".png"));
            }
            Timer timer = new Timer(100, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    /// la il faut mette une condtion pour que le mechant ne marche pas quand il y a
                    /// defender
                    gifX -= 2;
                    currentFrameIndex = (currentFrameIndex + 1) % gifFrames.length;
                    repaint();
                }
            });
            timer.start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    ////////////////////////////// SOURSI--DEBUT////////////////////////////

    @Override
    public void mouseReleased(MouseEvent e) {
        int column = e.getX() / this.cellWidth;
        // System.out.println("colonne " + column);
        int line = (e.getY() - 100) / this.cellHeight;
        // System.out.println("line " + line);
        if (is_image_clicked_peashooter) {
            Defender1 def = new Defender1();
            this.battle.DEFENDER.add(def);
            add(line, column, def);
            if (!((e.getX() >= 0 && e.getX() <= 900) && (e.getY() >= 0 && e.getY() <= 100))) {
                imagePositions.add(
                        new Point((column * cellWidth) - (imageIcon.getIconWidth() / 2) + 30,
                                ((line + 1) * cellHeight - (imageIcon.getIconHeight() / 2)) + 30));// faire line +1 car
                                                                                                   // quand
                                                                                                   // line est à 0
                is_image_clicked_peashooter = false;
                // is_image_clicked_sun = false;
                repaint();
            }
        }
    }

    public void intailise_shopping() {

    }

    @Override
    public void mousePressed(MouseEvent e) {

        // System.out.println(e.getX() + " ,   " + e.getY());
        if (((e.getX() >= 98 && e.getX() <= 144)) && (e.getY() >= 17 && e.getY() <= 80)) {
            is_image_clicked_peashooter = true;
        }

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (is_image_clicked_peashooter) {
            this.imageIcon = new ImageIcon("src/img/plantput/pea.png");
            repaint();
        }
        if (is_image_clicked_sun) {
            this.imageIcon = new ImageIcon("src/img/plantput/sun.png");
            repaint();
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    ////////////////////////////// SOURIS---FIN ////////////////////////////

    ////////// METHODE HELPER FUNCTIONS //////////

    public void add(int line, int column, Mob mob) {
        this.map[line][column].setMob(mob);
        this.map[line][column].setPresent(true);
        this.map[line][column].getMob().setDelatXY(line, column);
    }

    public void initialiseArray() {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                if (map[i][j].Get_Enemy_present()) {
                    enemies.add(map[i][j].getMob());
                }
            }
        }
    }

    public void end() {
        System.out.println("Game over!");
        System.exit(0);
    }

    public void printPosition() {
        for (int i = 0; i < position.length; i++) {
            for (int j = 0; j < position[i].length; j++) {
                if (j == 0) {
                    System.out.print(" i : [" + position[i][j] + "] ");
                } else {
                    System.out.print(" j : [" + position[i][j] + "] ");
                }
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Game Window");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                PlantvsZombie game = new PlantvsZombie();
                frame.add(game);

                frame.pack();
                frame.setLocationRelativeTo(null); // Centre la fenêtre
                frame.setResizable(false);
                frame.setVisible(true);
            }
        });
    }
}
