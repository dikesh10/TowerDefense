package model;

import java.util.Scanner;

public class Launcher {

    public Launcher() {
        MapConfig_Simple map = new MapConfig_Simple();
        MapConfig_Moyen config = new MapConfig_Moyen();
        Marathon marathon = new Marathon();

        String exit = "exit";
        int Ascii_value_exit = 0;
        for (int i = 0; i < exit.length(); i++) {
            Ascii_value_exit += ((int) exit.charAt(i));
        }
        System.out.println(Ascii_value_exit);

        boolean arret = true;
        while (arret) {

            String choice = value();
            if (choice.equals("0")) {
                // MapConfig.main(new String[0]);
                arret = false;
                map.loop();
            } else if (choice.equals("1")) {
                arret = false;
                config.loop();
                // MapConfig1.main(new String[0]);
            } else if (choice.equals("0")) {
                arret = false;
                System.out.println("On pas pas encore encoire fait le niveau dure");
            } else if (choice.equals("9")) {
                arret = false;
                marathon.loop();
            } else if (choice.equals("exit")) {
                System.exit(0);
            } else {
                System.out.println("\nVous n'avez pas bien rentré le numéro, veuillez réssayer\n");
            }
        }
    }

    public static String value() {
        System.out.println("\n");
        System.out.print(
                "Bonjour, veuillez choisir le niveau de difficulté souhaité (0,1) (pour le mode marathon, tapez 9 et pour quitter `exit`) : ");
        String userInput;
        try {
            Scanner scanner = new Scanner(System.in);
            userInput = scanner.next();
        } catch (Exception e) {
            System.out.println("Vous êtes sorti brutalement");
            userInput = "";
        }
        return userInput;
    }

    public static void main(String[] args) {
        new Launcher();
    }
}
