package model.enemy;

import model.MapConfig_Simple;
import model.Mob;

public class ENEMY_0 extends Mob {

        public ENEMY_0(String name, String display) {
                super(name, display);
        }

        @Override
        public void attack(MapConfig_Simple map) {

        }
}
