package model.enemy;

import model.MapConfig_Simple;
import java.awt.*;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.File;

public class Enemy1 extends Mechant {
    private static final String display = "x";
    private boolean Here = true;
    private final int damage = 2;
    private final static String file_path = "src/ressources/darkzombie/Frame";

    public Enemy1() {
        // super("Enemy1", display);
        super("Plant", display, 2);
        super.setUrl(file_path);
        super.setNumberFrame(17);

        // Image[] frame = new Image[super.getNumberFrame()];

        // try {
        // for (int i = 0; i < frame.length; i++) {
        // frame[i] = ImageIO.read(new File("src/ressources/darkzombie/Frame" + i +
        // ".png"));
        // }
        // } catch (IOException e) {
        // e.printStackTrace();
        // }
        // super.setGifFrames(frame);
    }

    
    public static void main(String[] args) {
        Enemy1 a = new Enemy1();

        System.out.println(a.getNumberFrame());
    }

}