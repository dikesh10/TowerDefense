package model.enemy;

import model.MapConfig_Simple;

public class Enemy2 extends Mechant {
    // private static final String display = "=";
    // private final int damage = 3;
    private final String file_path ="src/darkzombie/Frame";

    public Enemy2() {
        super("Enemy1", "=", 3);
    }


    public static void main(String[] args) {
        Enemy2 a = new Enemy2();
        System.out.println("Original File Path: " + a.file_path);
    
        for (int j = 0; j < 10; j++) {
            char[] newPathChars = a.file_path.toCharArray(); // Convert string to char array
            for (int i = 0; i < newPathChars.length; i++) {
                if (newPathChars[i] == '0') {
                    newPathChars[i] = (char) (j + '0'); // Replace '0' with a digit from 0 to 9
                    String newFilePath = new String(newPathChars); // Convert char array back to string
                  
                    System.out.println(newFilePath);
                }
            }
        }
    }
    

}