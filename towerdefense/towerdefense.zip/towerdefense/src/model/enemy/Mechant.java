package model.enemy;

import model.MapConfig_Simple;
import model.Mob;

public class Mechant extends Mob {

    public Mechant(String name, String Display, int damage) {
        super(name, Display);
        super.setDamageIntensity(damage);
    }

    @Override
    public void attack(MapConfig_Simple battle) {
        int i = this.getDeltaXY()[0];
        int j = this.getDeltaXY()[1];
        battle.map[i][j].getMob()
                .setHealth_points(battle.map[i][j].getMob().getHealth_points() - super.getDamageIntensity());
        if (battle.map[i][j].getMob().getHealth_points() <= 0) {
            // il faut parcourir arraylist pour le supprimer de l'arraylist
            battle.suppAttack(battle.map[i][j].getMob());
            battle.map[i][j].setMob(null);
            battle.map[i][j].setPresent(false);
        }
    }

    @Override
    public String get_display() {
        int health_points = this.getHealth_points();
        if (health_points <= 9) {
            return super.get_display() + super.get_display() + health_points;
        }
        return super.get_display() + 10;
    }
}