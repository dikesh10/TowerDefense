package model;

import java.util.ArrayList;
import java.util.Random;

import model.enemy.*;

public class Marathon extends MapConfig_Simple {

    private static int Vague = 0;
    public ArrayList<Mob> Enemie = new ArrayList<>();

    public Marathon() {
        super();
    }

    public int find_number_of_free_cases() {
        int count_free_case = 0;
        for (int i = 0; i < this.map.length; i++) {
            for (int j = 0; j < this.map[i].length; j++) {
                if (!map[i][j].getPresent()) {
                    count_free_case++;
                }
            }
            

        }
        return count_free_case;
    }

    public void spwan_till_death() {
        Random random = new Random();
        // int numbre_of_free_Case = find_number_of_free_cases();

        int numberOfEnemiesToSpawn = find_number_of_free_cases();
        System.out.println(numberOfEnemiesToSpawn );
        while (numberOfEnemiesToSpawn > 0) {
            int line = random.nextInt(5);
            int column = random.nextInt(6) + 10;

            if (!present(line, column)) {
                if (line < map.length && column < map[0].length) {
                    int random_Type_ennemie = random.nextInt(2);

                    if (random_Type_ennemie == 0) {
                        map[line][column].setMob(new Enemy1());
                        map[line][column].Set_Enemy_present(true);
                        map[line][column].setPresent(true);
                    } else {
                        map[line][column].setMob(new Enemy2());
                        map[line][column].Set_Enemy_present(true);
                        map[line][column].setPresent(true);
                    }
                    numberOfEnemiesToSpawn--;
                }
            }
        }

    }

    public void loop() {
        this.afficher();
        while (!lose()) {
            if (win() && (Vague == 2)) {
                spwan_till_death();
                this.afficher();
                System.out.println("Ennemi ultime");

            }
            this.player1.setMoney(this.player1.getMoney() + 10);
            if (this.player1.getMoney() >= 100) {
                call();
            } else {
                call_no_money();
            }
            this.move_Left();
            this.attack();
            if (win() && (Vague == 0)) {
                this.afficher();
                spawn2();
                Vague++;
            }

            if (win() && (Vague == 1)) {
                this.afficher();
                spawn3();
                Vague++;
            }

        }
        System.out.println("La partie est terminé, vous avez perdu\n");
    }

    public void spawn(int numberOfEnemiesToSpawn) {
        Random random = new Random();

        while (numberOfEnemiesToSpawn > 0) {
            int line = random.nextInt(5);
            int column = random.nextInt(6) + 10;

            if (!present(line, column)) {
                if (line < map.length && column < map[0].length) {
                    int random_Type_ennemie = random.nextInt(2);

                    if (random_Type_ennemie == 0) {
                        map[line][column].setMob(new Enemy1());
                        map[line][column].Set_Enemy_present(true);
                        map[line][column].setPresent(true);
                    } else {
                        map[line][column].setMob(new Enemy2());
                        map[line][column].Set_Enemy_present(true);
                        map[line][column].setPresent(true);
                    }
                    numberOfEnemiesToSpawn--;
                }
            }
        }
    }

    // spawn2 to spawn 6 enemies
    public void spawn2() {
    
        spawn(1); // Spawn 6 enemies
    }

    // spawn3 to spawn 3 enemies
    public void spawn3() {

     

        spawn(1); // Spawn 3 enemies
    }

    public static void main(String[] args) {
        Marathon a = new Marathon();
        a.loop();
    }

}