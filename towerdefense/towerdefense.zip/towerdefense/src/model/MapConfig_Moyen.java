package model;

import java.util.Random;
import model.enemy.*;

public class MapConfig_Moyen extends MapConfig_Simple {

    private static int Vague = 0;

    public MapConfig_Moyen() {
        super();
    }

    public void loop() {
        System.out.println("this is loop2");
        this.afficher();
        while (!lose() && (Vague <= 2)) {
            if (win() && (Vague == 2)) {
                this.afficher();
                System.out.println("vous avez gagner");
                return;
            }
            this.player1.setMoney(this.player1.getMoney() + 10);
            if (this.player1.getMoney() >= 100) {
                call();
            } else {
                call_no_money();
            }
            this.move_Left();
            this.attack();
            if (win() && (Vague == 0)) {
                this.afficher();
                spawn2();
                Vague++;
            }
            if (win() && (Vague == 1)) {
                this.afficher();
                spawn3();
                Vague++;
            }
        }
        System.out.println("La partie est terminé, vous avez perdu\n");
    }

    public void spawn(int numberOfEnemiesToSpawn) {
        Random random = new Random();
        while (numberOfEnemiesToSpawn > 0) {
            int line = random.nextInt(5);
            int column = random.nextInt(6) + 10;
            if (!present(line, column)) {
                if (line < map.length && column < map[0].length) {
                    int random_Type_ennemie = random.nextInt(2);
                    if (random_Type_ennemie == 0) {
                        map[line][column].setMob(new Enemy1());
                        map[line][column].Set_Enemy_present(true);
                        map[line][column].setPresent(true);
                    } else {
                        map[line][column].setMob(new Enemy2());
                        map[line][column].Set_Enemy_present(true);
                        map[line][column].setPresent(true);
                    }
                    numberOfEnemiesToSpawn--;
                }
            }
        }
    }

    public void spawn2() {
        spawn(6);
    }

    // spawn3 to spawn 3 enemies
    public void spawn3() {
        spawn(3); // Spawn 3 enemies
    }

    public static void main(String[] args) {
        System.out.println("MapConfig_Moyen");
        MapConfig_Moyen config = new MapConfig_Moyen();
        System.out.println(config.getPlayer().getMoney() + " l'argent de joueur dans le jeu");
        // config.loop();
        config.loop();
    }
}